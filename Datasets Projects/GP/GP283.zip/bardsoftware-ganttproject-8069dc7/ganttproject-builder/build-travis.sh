#!/bin/bash
cd ganttproject-builder
ant
