In most cases GanttProject requires no installation.
Just run 'ganttproject.bat' or 'ganttproject' shell scripts depending on
whether you're on Windows or Linux. On Linux systems you may want to create
a symbolic link to ganttproject shell script in /usr/local/bin or in ~/bin

For more information and troubleshooting, visit
http://code.google.com/p/ganttproject/wiki/InstallingFromZIPArchive
