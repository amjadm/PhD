/**
 * Basic demo applications showing the use of JFreeChart in JavaFX.
 */
package org.jfree.chart.fx.demo;
