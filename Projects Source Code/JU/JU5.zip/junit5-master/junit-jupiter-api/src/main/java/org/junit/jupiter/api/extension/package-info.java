/**
 * JUnit Jupiter API for writing extensions.
 */

package org.junit.jupiter.api.extension;
