/**
 * JUnit v4.x Test for the Money example.
 *
 * @since 4.0
 * @see junit.samples.money.Money
 */
package org.junit.samples.money;